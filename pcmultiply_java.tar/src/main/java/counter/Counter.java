package counter;

//import java.util.concurrent.locks.Lock;
//import java.util.concurrent.locks.ReentrantLock;

/**
 *  TO DO: This counter needs to be synchronized..
 */
public class Counter
{
	private int value;
	
	/**
	 * The constructor initiate the counter's value
	 */
	public Counter()
	{
		value = 0;
	}
	
	/**
	 * The method increment the value of the counter
	 */
	public void increment()
	{
            value++;
	}
	
	/**
	 * The method return the value of the counter
	 * @return the value of the counter
	 */
	public int get()
	{
            int value = 0;
            value = this.value;
            return value;
	}
}
