package worker;

import pcmultiply.PCMatrix;

public class Buffer 
{

    // Bounded buffer data storage
    // Feel free to customize the data type
    private Matrix[] bigMatrix = new Matrix[PCMatrix.BOUNDED_BUFFER_SIZE];

    // Bounded buffer put() and get()
    public void put(Matrix matrix)
    {
        
    }

    public Matrix get()
    {
        return null;
    }

}
