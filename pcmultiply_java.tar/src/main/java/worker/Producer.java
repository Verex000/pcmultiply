package worker;

public class Producer
implements Runnable
{

	public void run()
	{
		// TODO Auto-generated method stub
		
	}

}
