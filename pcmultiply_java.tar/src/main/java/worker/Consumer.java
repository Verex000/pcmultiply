package worker;

public class Consumer
implements Runnable
{

	public void run()
	{
		// TODO Auto-generated method stub
		
	}

}
